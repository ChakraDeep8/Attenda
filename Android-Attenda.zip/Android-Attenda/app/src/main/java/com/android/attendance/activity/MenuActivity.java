package com.android.attendance.activity;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import com.android.attendance.bean.AttendanceBean;
import com.android.attendance.bean.StudentBean;
import com.android.attendance.context.ApplicationContext;
import com.android.attendance.db.DBAdapter;
import com.example.androidattendancesystem.R;

import android.Manifest;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.os.Environment;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;


public class MenuActivity extends Activity {

	Button addStudent;
	Button addFaculty;
	Button viewStudent;
	Button viewFaculty;
	Button logout;
	Button attendancePerStudent;
	ImageButton exl;
	ArrayList<StudentBean> studentBeans;
	Date c = Calendar.getInstance().getTime();
	SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		addStudent = (Button) findViewById(R.id.buttonaddstudent);
		addFaculty = (Button) findViewById(R.id.buttonaddfaculty);
		viewStudent = (Button) findViewById(R.id.buttonViewstudent);
		viewFaculty = (Button) findViewById(R.id.buttonviewfaculty);
		logout = (Button) findViewById(R.id.buttonlogout);
		exl = (ImageButton) findViewById(R.id.img_excel);

		exl.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MenuActivity.this, empty.class);
				startActivity(intent);
			}
		});
		addStudent.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intent = new Intent(MenuActivity.this, AddStudentActivity.class);
				startActivity(intent);
			}
		});

		addFaculty.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intent = new Intent(MenuActivity.this, AddFacultyActivity.class);
				startActivity(intent);
			}
		});

		viewFaculty.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intent = new Intent(MenuActivity.this, ViewFacultyActivity.class);
				startActivity(intent);
			}
		});


		viewStudent.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				DBAdapter dbAdapter;

				// TODO Auto-generated method stub

				Intent intent = new Intent(MenuActivity.this, ViewStudentActivity.class);
				startActivity(intent);
			}
		});
		logout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intent = new Intent(MenuActivity.this, MainActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		attendancePerStudent = (Button) findViewById(R.id.attendancePerStudentButton);
		attendancePerStudent.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				DBAdapter dbAdapter = new DBAdapter(MenuActivity.this);
				ArrayList<AttendanceBean> attendanceBeanList = dbAdapter.getAllAttendanceByStudent();
				((ApplicationContext) MenuActivity.this.getApplicationContext()).setAttendanceBeanList(attendanceBeanList);

				Intent intent = new Intent(MenuActivity.this, ViewAttendancePerStudentActivity.class);
				startActivity(intent);

			}
		});
	}







	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
